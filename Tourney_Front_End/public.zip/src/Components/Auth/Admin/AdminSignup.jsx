import React from 'react'

const AdminSignup = () => {
  return (
    <div>
      
    </div>
  )
}

export default AdminSignup
